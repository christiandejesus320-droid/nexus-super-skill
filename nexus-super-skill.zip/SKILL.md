---
name: nexus-super-skill
description: Super skill para Claude Code optimizada para ejecución de objetivos (/goal) y bucles de trabajo (/loop) con enfoque en resultados de negocio (NEXUS LABS).
---

# NEXUS Super Skill

Esta skill fusiona las capacidades de persistencia de objetivos, gestión de fases y prevención de detención prematura (Stop Gate), todo bajo el marco operativo de **NEXUS LABS**: Diagnóstico → Acción → Sistema → Mejora.

## Comandos Principales

### `/goal [objetivo]`
Establece un objetivo persistente para la sesión actual. 
- **Uso**: `/goal crear funnel de ventas para agencia de automatización`
- **Efecto**: Crea una entrada en SQLite y activa el **Stop Gate**. Claude no se detendrá hasta que el objetivo se complete o se pause.

### `/loop`
Gestiona el ciclo de vida del proyecto actual.
1. **Planificar**: Divide el objetivo en fases accionables.
2. **Ejecutar**: Toma la siguiente fase pendiente.
3. **Evidencia**: Genera pruebas reales de que el trabajo funciona.
4. **Verificar**: Audita el resultado antes de marcar como completado.

### `/nexus status`
Muestra el estado actual del objetivo, presupuesto de tokens y progreso de las fases.

### `/nexus clear`
Limpia el estado de la sesión actual si deseas empezar de cero.

## Workflow Operativo (Estilo NEXUS)

Cuando un objetivo está activo, cada turno debe seguir esta estructura mental:

1. **Diagnóstico**: ¿En qué fase estamos? ¿Qué bloquea el progreso?
2. **Acción Inmediata**: Ejecutar el código/tarea necesaria AHORA. No planificar para mañana.
3. **Sistema**: Si la tarea es repetitiva, crear un script o plantilla.
4. **Mejora**: Optimizar para conversión o velocidad.

## Reglas Críticas

- **No Teoría**: Si el usuario pide un plan, dale el plan Y el primer archivo de código.
- **Stop Gate**: Si intentas terminar la sesión (`Stop`), la skill verificará si el objetivo NEXUS está cumplido. Si no, te pedirá continuar.
- **Resultados**: Prioriza siempre lo que genera ingresos o valor directo al cliente.

## Integración Técnica

La skill utiliza un motor en Python (`scripts/nexus_engine.py`) para gestionar el estado. 
- Ubicación del estado: `~/.nexus/nexus_state.sqlite`
- Identificador de sesión: Basado en `TERM_SESSION_ID` para máxima estabilidad.
